import React, { useState, useRef, useCallback, useEffect } from 'react';
import { jsPDF } from 'jspdf';
import { Document, Packer, Paragraph, TextRun, ShadingType, AlignmentType } from 'docx';
import MenuBar from './components/MenuBar';
import Toolbar from './components/Toolbar';
import Editor from './components/Editor';
import StatusBar from './components/StatusBar';
import Modal from './components/Modal';
import { DEFAULT_FILENAME, APP_TITLE, AVAILABLE_FONTS, ICONS, FOG_HORN_SOUND_URI } from './constants';

const INACTIVITY_TIMEOUT_MS = 60 * 1000; // 1 minute for encouragement mode
const TYPING_INACTIVITY_THRESHOLD_MS = 2000; // 2 seconds for typing duration calculation

const formatDuration = (ms: number): string => {
    const totalSeconds = Math.floor(ms / 1000);
    const hours = Math.floor(totalSeconds / 3600);
    const minutes = Math.floor((totalSeconds % 3600) / 60);
    const seconds = totalSeconds % 60;
    return `${String(hours).padStart(2, '0')}:${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;
};

const App: React.FC = () => {
  const [fileName, setFileName] = useState<string>(DEFAULT_FILENAME);
  const [fileContent, setFileContent] = useState<string>('');
  const [isDirty, setIsDirty] = useState<boolean>(false);
  const [showAboutModal, setShowAboutModal] = useState<boolean>(false);
  // Font is now fixed to Times New Roman
  const [currentFont, setCurrentFont] = useState<string>(AVAILABLE_FONTS[0].family); 
  const [darkMode, setDarkMode] = useState<boolean>(false);
  
  const [editorSelection, setEditorSelection] = useState<{ start: number; end: number }>({ start: 0, end: 0 });

  // Encouragement Mode State
  const [encouragementModeActive, setEncouragementModeActive] = useState<boolean>(false);
  const [showAngryMan, setShowAngryMan] = useState<boolean>(false);
  const inactivityTimerRef = useRef<NodeJS.Timeout | null>(null);
  const fogHornAudioRef = useRef<HTMLAudioElement>(null);

  // Usage Stats State
  const sessionStartTimestampRef = useRef<number>(Date.now());
  const accumulatedTypingTimeMsRef = useRef<number>(0);
  const currentTypingBurstStartTimestampRef = useRef<number | null>(null);
  const typingEndTimerRef = useRef<NodeJS.Timeout | null>(null);

  const editorRef = useRef<HTMLTextAreaElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (darkMode) {
      document.body.classList.add('theme-dark');
    } else {
      document.body.classList.remove('theme-dark');
    }
  }, [darkMode]);

  // --- Encouragement Mode Logic ---
  const playFogHorn = useCallback(() => {
    if (fogHornAudioRef.current) {
      fogHornAudioRef.current.currentTime = 0;
      fogHornAudioRef.current.play().catch(error => console.warn("Audio play failed:", error));
    }
  }, []);

  const clearInactivityTimer = useCallback(() => {
    if (inactivityTimerRef.current) {
      clearTimeout(inactivityTimerRef.current);
      inactivityTimerRef.current = null;
    }
  }, []);
  
  const startInactivityTimer = useCallback(() => {
    clearInactivityTimer();
    if (encouragementModeActive) {
      inactivityTimerRef.current = setTimeout(() => {
        playFogHorn();
        setShowAngryMan(true);
      }, INACTIVITY_TIMEOUT_MS);
    }
  }, [encouragementModeActive, playFogHorn, clearInactivityTimer]);

  const resetEncouragementState = useCallback(() => {
    clearInactivityTimer();
    setShowAngryMan(false);
  }, [clearInactivityTimer]);

  const handleToggleEncouragementMode = () => {
    const newModeState = !encouragementModeActive;
    setEncouragementModeActive(newModeState);
    if (newModeState) {
      startInactivityTimer();
    } else {
      resetEncouragementState();
    }
  };
  
  useEffect(() => {
    if (encouragementModeActive) {
      startInactivityTimer();
    } else {
      resetEncouragementState();
    }
    return () => clearInactivityTimer();
  }, [encouragementModeActive, fileContent, startInactivityTimer, resetEncouragementState, clearInactivityTimer]);


  // --- File Operations ---
  const handleNewFile = useCallback(() => {
    if (isDirty) {
      if (!window.confirm('You have unsaved changes. Are you sure you want to start a new file?')) {
        return;
      }
    }
    setFileContent('');
    setFileName(DEFAULT_FILENAME);
    setIsDirty(false);
    setEditorSelection({ start: 0, end: 0 });
    if (editorRef.current) editorRef.current.focus();
    if (encouragementModeActive) {
        resetEncouragementState();
        startInactivityTimer();
    }
  }, [isDirty, encouragementModeActive, resetEncouragementState, startInactivityTimer]);

  const handleOpenFile = useCallback(() => {
    if (isDirty) {
      if (!window.confirm('You have unsaved changes. Are you sure you want to open a new file?')) {
        return;
      }
    }
    if (fileInputRef.current) {
      fileInputRef.current.click();
    }
  }, [isDirty]);

  const handleFileSelected = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file && file.type === 'text/plain') {
      const reader = new FileReader();
      reader.onload = (e) => {
        const text = e.target?.result as string;
        setFileContent(text);
        setFileName(file.name);
        setIsDirty(false);
        setEditorSelection({ start: text.length, end: text.length });
        if (editorRef.current) editorRef.current.focus();
        if (encouragementModeActive) {
            resetEncouragementState();
            startInactivityTimer();
        }
      };
      reader.readAsText(file);
    } else if (file) {
      alert('Only .txt files are supported for opening.');
    }
    if (event.target) {
      event.target.value = '';
    }
  };

  const handleSaveFile = useCallback(() => {
    const blob = new Blob([fileContent], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = fileName.endsWith('.txt') ? fileName : `${fileName}.txt`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
    setIsDirty(false);
  }, [fileContent, fileName]);

  const handleExportPDF = useCallback(() => {
    try {
      const doc = new jsPDF();
      const pdfFont = 'Times-Roman'; // Fixed to Times New Roman
      
      doc.setFont(pdfFont);
      doc.setFontSize(12); // Set font size to 12pt
      doc.text(fileContent, 10, 10);
      const pdfFileName = (fileName.lastIndexOf('.') > 0 ? fileName.substring(0, fileName.lastIndexOf('.')) : fileName) + '.pdf';
      doc.save(pdfFileName);
    } catch (error) {
      console.error("Error exporting PDF:", error);
      alert("Failed to export PDF. Check console for details.");
    }
  }, [fileContent, fileName]); // currentFont removed as it's fixed

  const handleExportDOCX = useCallback(async () => {
    try {
      const doc = new Document({
        sections: [{
          properties: {},
          children: [
            new Paragraph({
              children: [
                new TextRun({
                  text: fileContent,
                  font: "Times New Roman", // Specify Times New Roman
                  size: 24, // 12pt (12 * 2 = 24 half-points)
                }),
              ],
            }),
          ],
        }],
      });
      const docxFileName = (fileName.lastIndexOf('.') > 0 ? fileName.substring(0, fileName.lastIndexOf('.')) : fileName) + '.docx';
      const blob = await Packer.toBlob(doc);
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = docxFileName;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);
    } catch (error) {
      console.error("Error exporting DOCX:", error);
      alert("Failed to export DOCX. Check console for details.");
    }
  }, [fileContent, fileName]);


  const handleSaveUsageStats = useCallback(() => {
    const totalSessionTimeMs = Date.now() - sessionStartTimestampRef.current;
    let finalAccumulatedTypingTimeMs = accumulatedTypingTimeMsRef.current;

    if (currentTypingBurstStartTimestampRef.current) {
      finalAccumulatedTypingTimeMs += (Date.now() - currentTypingBurstStartTimestampRef.current);
    }
    const currentWordCount = fileContent.trim() === '' ? 0 : fileContent.trim().split(/\s+/).length;

    const statsContent = `Wes Word 95 - Usage Statistics
Report Generated: ${new Date().toLocaleString()}
------------------------------------
Total Session Duration: ${formatDuration(totalSessionTimeMs)}
Active Typing Duration: ${formatDuration(finalAccumulatedTypingTimeMs)}
Words in Document: ${currentWordCount}
Filename: ${fileName}
------------------------------------
`;
    const blob = new Blob([statsContent], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    const safeFileName = fileName.replace(/[^a-z0-9_.-]/gi, '_');
    link.download = `Usage-Stats-${safeFileName}.txt`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);

  }, [fileContent, fileName]);


  const handleTextChange = (newContent: string, newCursorPos?: number) => {
    setFileContent(newContent);
    setIsDirty(true);

    if (newCursorPos !== undefined) {
        setEditorSelection({ start: newCursorPos, end: newCursorPos });
    } else if (editorRef.current) {
        // Fallback if newCursorPos isn't provided, though usually it is.
        setEditorSelection({ start: editorRef.current.selectionStart, end: editorRef.current.selectionEnd });
    }
    
    // Encouragement Mode: Reset timer on typing
    if (encouragementModeActive) {
      resetEncouragementState();
      startInactivityTimer();    
    }

    // Usage Stats: Track typing duration
    if (typingEndTimerRef.current) clearTimeout(typingEndTimerRef.current);
    if (currentTypingBurstStartTimestampRef.current === null) {
        currentTypingBurstStartTimestampRef.current = Date.now();
    }
    typingEndTimerRef.current = setTimeout(() => {
        if (currentTypingBurstStartTimestampRef.current) {
            accumulatedTypingTimeMsRef.current += (Date.now() - currentTypingBurstStartTimestampRef.current);
            currentTypingBurstStartTimestampRef.current = null;
        }
    }, TYPING_INACTIVITY_THRESHOLD_MS);
  };
  
  const executeCommand = (command: 'cut' | 'copy' | 'paste') => {
    if (editorRef.current) {
        editorRef.current.focus();
        const currentSelectionStart = editorRef.current.selectionStart;
        const currentSelectionEnd = editorRef.current.selectionEnd;
        
        try {
            const success = document.execCommand(command);
            
            // execCommand is synchronous, but its effect on the textarea value might not be immediately reflected in React's state.
            // We need to re-read the value from the textarea and update React state.
            setTimeout(() => {
                if(editorRef.current) {
                    const newText = editorRef.current.value;
                    const newCursorPos = editorRef.current.selectionStart;
                    
                    if (command === 'cut' || command === 'paste') {
                        // For cut and paste, the content and cursor position change.
                        handleTextChange(newText, newCursorPos); 
                    } else if (command === 'copy') {
                         // For copy, only selection might change if user selected different text during the operation,
                         // but typically, the content doesn't. So, update selection.
                         setEditorSelection({ start: newCursorPos, end: editorRef.current.selectionEnd });
                    }
                }
            }, 0);

            if (!success && command === 'paste') { 
                navigator.clipboard.readText().then(text => {
                    if (editorRef.current) {
                        const ta = editorRef.current;
                        const start = ta.selectionStart;
                        const end = ta.selectionEnd;
                        const updatedText = ta.value.substring(0, start) + text + ta.value.substring(end);
                        handleTextChange(updatedText, start + text.length);
                    }
                }).catch(err => console.error('Failed to paste using clipboard API:', err));
            }
        } catch (e) {
            console.error(`Error executing command ${command}:`, e);
        }
    }
  };

  const handleCut = useCallback(() => executeCommand('cut'), []); // Removed dependencies to avoid stale closures with fixed currentFont
  const handleCopy = useCallback(() => executeCommand('copy'), []);
  const handlePaste = useCallback(() => executeCommand('paste'), []);


  const handleIndent = useCallback(() => {
    if (!editorRef.current) return;
    const ta = editorRef.current;
    const { selectionStart, selectionEnd, value } = ta;
    
    let lineStartIndex = value.lastIndexOf('\n', selectionStart - 1) + 1;
    // For selectionEnd, if it's at the start of a new line after a newline char, 
    // we don't want to include that newline character's line in the indentation.
    // So, we search for the newline from selectionEnd -1.
    let lineEndIndex = value.indexOf('\n', selectionEnd > 0 ? selectionEnd -1 : 0 ); 
    if (lineEndIndex === -1 || lineEndIndex < lineStartIndex ) lineEndIndex = value.length;


    const prefix = value.substring(0, lineStartIndex);
    const suffix = value.substring(lineEndIndex); 
    const selectedLinesText = value.substring(lineStartIndex, lineEndIndex);

    const linesToIndent = selectedLinesText.split('\n');
    const newLines = linesToIndent.map(line => '\t' + line).join('\n');
    const numberOfTabsAdded = linesToIndent.length; 
    
    const finalNewContent = prefix + newLines + suffix;
    
    let newCursorStartPos; 
    let newCursorEndPos; 

    if (selectionStart !== selectionEnd) { // Multi-line or partial line selection
        newCursorStartPos = selectionStart + 1; // Indent might shift start
        newCursorEndPos = selectionEnd + numberOfTabsAdded;
    } else { // Single cursor position
        newCursorStartPos = selectionStart + 1;
        newCursorEndPos = newCursorStartPos;
    }
    
    handleTextChange(finalNewContent, newCursorStartPos);
    // After handleTextChange, editorSelection is set to newCursorStartPos for both start/end.
    // If we had a multi-line selection, we want to re-select the indented block.
     if (selectionStart !== selectionEnd) {
        // Set selection after React re-render ensures editorRef is updated
        setTimeout(() => {
          if(editorRef.current) {
            // Recalculate the start for multi-line indent, it should remain at the start of the first indented line
            const actualNewStart = lineStartIndex; 
            const actualNewEnd = lineStartIndex + newLines.length;
            editorRef.current.setSelectionRange(actualNewStart, actualNewEnd);
            setEditorSelection({start: actualNewStart, end: actualNewEnd});
          }
        }, 0);
     } else {
        setEditorSelection({ start: newCursorStartPos, end: newCursorEndPos });
     }

  }, [fileContent, handleTextChange]); // Removed encouragementModeActive, currentFont as they don't change


  const handleToggleDarkMode = () => {
    setDarkMode(prev => !prev);
  };
  
  useEffect(() => {
    const handleGlobalKeyDown = (event: KeyboardEvent) => {
      if (event.ctrlKey || event.metaKey) {
        switch (event.key.toLowerCase()) {
          case 'n': event.preventDefault(); handleNewFile(); break;
          case 'o': event.preventDefault(); handleOpenFile(); break;
          case 's': event.preventDefault(); handleSaveFile(); break;
        }
      }
    };
    window.addEventListener('keydown', handleGlobalKeyDown);
    return () => window.removeEventListener('keydown', handleGlobalKeyDown);
  }, [handleNewFile, handleOpenFile, handleSaveFile]);

  // Cleanup for typingEndTimerRef on component unmount
  useEffect(() => {
    return () => {
        if (typingEndTimerRef.current) {
            clearTimeout(typingEndTimerRef.current);
        }
        if (currentTypingBurstStartTimestampRef.current) { 
            accumulatedTypingTimeMsRef.current += (Date.now() - currentTypingBurstStartTimestampRef.current);
            currentTypingBurstStartTimestampRef.current = null;
        }
    };
  }, []);
  
  const wordCount = fileContent.trim() === '' ? 0 : fileContent.trim().split(/\s+/).length;
  const charCount = fileContent.length;

  return (
    <div className={`app-container flex flex-col h-screen max-w-4xl mx-auto my-2 shadow-2xl border-t-2 border-l-2 border-white border-r-2 border-b-2 border-black`}>
      <MenuBar
        onNew={handleNewFile}
        onOpen={handleOpenFile}
        onSave={handleSaveFile}
        onExportPDF={handleExportPDF}
        onExportDOCX={handleExportDOCX}
        onSaveUsageStats={handleSaveUsageStats}
        onCut={handleCut}
        onCopy={handleCopy}
        onPaste={handlePaste}
        onAbout={() => setShowAboutModal(true)}
        fileName={fileName}
      />
      <Toolbar
        onNew={handleNewFile}
        onOpen={handleOpenFile}
        onSave={handleSaveFile}
        onCut={handleCut}
        onCopy={handleCopy}
        onPaste={handlePaste}
        onIndent={handleIndent}
        // currentFont and onFontChange removed
        darkMode={darkMode}
        onToggleDarkMode={handleToggleDarkMode}
        encouragementModeActive={encouragementModeActive}
        onToggleEncouragementMode={handleToggleEncouragementMode}
      />
      <Editor 
        content={fileContent} 
        onChange={handleTextChange} 
        editorRef={editorRef}
        currentFont={currentFont} // Will always be Times New Roman
        selectionStart={editorSelection.start}
        selectionEnd={editorSelection.end}
      />
      <StatusBar 
        fileName={fileName} 
        wordCount={wordCount} 
        charCount={charCount}
      />
      <input
        type="file"
        ref={fileInputRef}
        onChange={handleFileSelected}
        accept=".txt"
        className="hidden"
        aria-hidden="true"
      />
      <Modal 
        isOpen={showAboutModal} 
        onClose={() => setShowAboutModal(false)}
        title={`About ${APP_TITLE}`}
      >
        <div className="modal-body space-y-2">
            <p className="text-center text-lg font-bold">{APP_TITLE}</p>
            <p>Version 1.4 (React Edition)</p>
            <p>A retro-style text editor for .txt files, inspired by classic word processors of the mid-90s. Now with PDF/DOCX export, usage tracking, and a fixed Times New Roman 12px font.</p>
            <p>Created with React, TypeScript, and Tailwind CSS.</p>
            <p className="mt-4 text-center">&copy; {new Date().getFullYear()} Giant Evil Corporation and the Honorable Mr. Wes</p>
        </div>
      </Modal>

      <audio ref={fogHornAudioRef} src={FOG_HORN_SOUND_URI} preload="auto" />

      {showAngryMan && encouragementModeActive && (
        <div 
            className="fixed inset-0 flex flex-col items-center justify-center bg-black bg-opacity-60 z-[60]"
            onClick={() => { 
                resetEncouragementState();
                startInactivityTimer(); 
            }}
        >
          {ICONS.ANGRY_MAN}
          <p className="text-white text-2xl font-bold mt-4 animate-pulse">KEEP TYPING!</p>
        </div>
      )}
    </div>
  );
};

export default App;