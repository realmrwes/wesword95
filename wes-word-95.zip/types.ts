// Fix: Updated MenuItem to be a discriminated union.
// Actionable items require a 'label' and have 'isSeparator' as false or undefined.
// Separator items have 'isSeparator: true' and no 'label', 'action', or 'disabled' properties.

export type MenuItem =
  | {
      label: string;
      action?: () => void;
      disabled?: boolean;
      isSeparator?: false | undefined; // Discriminant for action items
    }
  | {
      isSeparator: true; // Discriminant for separators
      label?: never; // Separators should not have a label
      action?: never; // Separators should not have an action
      disabled?: never; // Separators should not be disabled
    };

export interface ToolbarButtonType {
  id: string;
  label: string; // For tooltip or if no icon
  icon?: React.ReactNode;
  action?: () => void;
  disabled?: boolean;
  tooltip: string;
  active?: boolean; // For toggle buttons like Dark Mode or WPM
}
