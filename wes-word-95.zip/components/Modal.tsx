import React from 'react';

interface ModalProps {
  isOpen: boolean;
  onClose: () => void;
  title: string;
  children: React.ReactNode;
}

const Modal: React.FC<ModalProps> = ({ isOpen, onClose, title, children }) => {
  if (!isOpen) return null;

  return (
    <div className="modal-overlay fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="modal-content bg-[#c0c0c0] border-t-2 border-l-2 border-white border-r-2 border-b-2 border-black p-1 shadow-lg w-full max-w-md">
        <div className="modal-title-bar bg-[#000080] text-white p-1 flex justify-between items-center">
          <h2 className="font-bold text-sm">{title}</h2>
          <button
            onClick={onClose}
            className="bg-[#c0c0c0] border-t border-l border-white border-r border-b border-black px-2 text-xs text-black font-bold hover:bg-gray-400 active:border-t-black active:border-l-black active:border-r-white active:border-b-white"
            aria-label="Close modal"
          >
            X
          </button>
        </div>
        <div className="modal-body p-4 text-sm">
          {children}
        </div>
        <div className="modal-footer flex justify-end p-2 bg-gray-300 border-t border-gray-400">
            <button
                onClick={onClose}
                className="bg-[#c0c0c0] border-t border-l border-white border-r border-b border-black px-4 py-1 text-sm text-black font-semibold hover:bg-gray-400 active:border-t-black active:border-l-black active:border-r-white active:border-b-white"
            >
                OK
            </button>
        </div>
      </div>
    </div>
  );
};

export default Modal;