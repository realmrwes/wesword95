import React, { useRef, useEffect } from 'react';

interface EditorProps {
  content: string;
  onChange: (newContent: string, newCursorPos?: number) => void;
  editorRef: React.RefObject<HTMLTextAreaElement>;
  currentFont: string; // Will always be Times New Roman family
  selectionStart: number;
  selectionEnd: number;
}

const Editor: React.FC<EditorProps> = ({ 
  content, 
  onChange, 
  editorRef, 
  currentFont,
  selectionStart,
  selectionEnd    
}) => {
  
  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Tab') {
      e.preventDefault();
      const target = e.currentTarget;
      const start = target.selectionStart;
      const end = target.selectionEnd;
      const value = target.value;
      const newValue = value.substring(0, start) + '\t' + value.substring(end);
      
      onChange(newValue, start + 1);
    }
  };

  useEffect(() => {
    if (editorRef.current && 
        (editorRef.current.selectionStart !== selectionStart || editorRef.current.selectionEnd !== selectionEnd)) {
      editorRef.current.selectionStart = selectionStart;
      editorRef.current.selectionEnd = selectionEnd;
    }
  }, [selectionStart, selectionEnd, editorRef, content]);

  return (
    <div className="editor-container flex-grow p-1 bg-[#c0c0c0]">
      <textarea
        ref={editorRef}
        value={content}
        onChange={(e) => onChange(e.target.value, e.target.selectionStart)}
        onKeyDown={handleKeyDown}
        onSelect={() => { 
          if (editorRef.current) {
            // Propagate selection changes to App.tsx.
            // App.tsx's handleTextChange updates editorSelection based on cursor pos.
            // This ensures that if a user selects text without typing, App.tsx knows.
            onChange(content, editorRef.current.selectionStart); 
          }
        }}
        className="editor-textarea w-full h-full p-2 box-border resize-none bg-white text-black 
                   border-2 border-t-gray-600 border-l-gray-600 
                   border-r-white border-b-white 
                   focus:outline-none focus:ring-1 focus:ring-blue-500"
        spellCheck="false"
        style={{ fontFamily: currentFont, fontSize: '12px' }} // Set font size to 12px
        aria-label="Text Editor"
        aria-multiline="true"
        role="textbox"
      />
    </div>
  );
};

export default Editor;