import React from 'react';
import { ToolbarButtonType } from '../types';
import { ICONS } from '../constants';

interface ToolbarProps {
  onNew: () => void;
  onOpen: () => void;
  onSave: () => void;
  onCut: () => void;
  onCopy: () => void;
  onPaste: () => void;
  onIndent: () => void;
  darkMode: boolean;
  onToggleDarkMode: () => void;
  encouragementModeActive: boolean;
  onToggleEncouragementMode: () => void;
}

const ToolbarButton: React.FC<{ button: ToolbarButtonType }> = ({ button }) => {
  return (
    <button
      title={button.tooltip}
      onClick={button.action}
      disabled={button.disabled}
      className={`toolbar-button p-1 m-0.5 w-7 h-7 flex items-center justify-center
                  border-t border-l border-white 
                  border-r border-b border-gray-600 
                  hover:bg-gray-300 
                  active:border-t-gray-600 active:border-l-gray-600 
                  active:border-r-white active:border-b-white
                  active:bg-gray-200
                  disabled:opacity-50 disabled:pointer-events-none
                  focus:outline-none focus:ring-1 focus:ring-blue-500 ${button.active ? 'bg-gray-200 border-t-gray-600 border-l-gray-600 border-r-white border-b-white' : ''}
                  `}
      aria-label={button.tooltip}
      aria-pressed={button.active}
    >
      {button.icon || <span className="text-xs font-mono">{button.label}</span>}
    </button>
  );
};

const Toolbar: React.FC<ToolbarProps> = ({ 
  onNew, onOpen, onSave, onCut, onCopy, onPaste, onIndent,
  darkMode, onToggleDarkMode,
  encouragementModeActive, onToggleEncouragementMode
}) => {
  const fileButtons: ToolbarButtonType[] = [
    { id: 'new', label: 'New', icon: ICONS.NEW_FILE, action: onNew, tooltip: 'New (Ctrl+N)' },
    { id: 'open', label: 'Open', icon: ICONS.OPEN_FILE, action: onOpen, tooltip: 'Open (Ctrl+O)' },
    { id: 'save', label: 'Save', icon: ICONS.SAVE_FILE, action: onSave, tooltip: 'Save (Ctrl+S)' },
  ];

  const editButtons: ToolbarButtonType[] = [
    { id: 'cut', label: 'Cut', icon: ICONS.CUT, action: onCut, tooltip: 'Cut (Ctrl+X)' },
    { id: 'copy', label: 'Copy', icon: ICONS.COPY, action: onCopy, tooltip: 'Copy (Ctrl+C)' },
    { id: 'paste', label: 'Paste', icon: ICONS.PASTE, action: onPaste, tooltip: 'Paste (Ctrl+V)' },
  ];
  
  const formattingButtons: ToolbarButtonType[] = [
    { id: 'indent', label: 'Indent', icon: ICONS.INDENT_RIGHT, action: onIndent, tooltip: 'Indent Text' },
  ];

  const utilityButtons: ToolbarButtonType[] = [
     { id: 'darkMode', label: 'Theme', icon: darkMode ? ICONS.SUN : ICONS.MOON, action: onToggleDarkMode, tooltip: darkMode ? 'Light Mode' : 'Dark Mode', active: darkMode },
     { id: 'encouragementToggle', label: 'Encourage', icon: ICONS.MEGAPHONE, action: onToggleEncouragementMode, tooltip: encouragementModeActive ? 'Disable Encouragement Mode' : 'Enable Encouragement Mode', active: encouragementModeActive },
  ];

  return (
    <div className="toolbar bg-[#c0c0c0] p-1 flex items-center space-x-1 border-b-2 border-gray-400 shadow-sm">
      {fileButtons.map(btn => <ToolbarButton key={btn.id} button={btn} />)}
      <div className="toolbar-separator h-6 w-px bg-gray-400 border-r border-white mx-1"></div>
      {editButtons.map(btn => <ToolbarButton key={btn.id} button={btn} />)}
      <div className="toolbar-separator h-6 w-px bg-gray-400 border-r border-white mx-1"></div>
      
      {formattingButtons.map(btn => <ToolbarButton key={btn.id} button={btn} />)}
      
      {/* Font selection removed as Times New Roman is now the only font */}
      {/* <select
        title="Change font"
        value={currentFont} // This would be fixed
        onChange={(e) => onFontChange(e.target.value)} // This would be removed
        className="toolbar-select-font p-1 m-0.5 h-7 bg-white border-t-gray-600 border-l-gray-600 border-r-white border-b-white border-2 text-xs focus:outline-none focus:ring-1 focus:ring-blue-500 appearance-none px-2"
        style={{ minWidth: '120px' }} 
      >
        {AVAILABLE_FONTS.map(font => ( // AVAILABLE_FONTS would only have Times New Roman
          <option key={font.family} value={font.family}>{font.name}</option>
        ))}
      </select> */}

      <div className="toolbar-separator h-6 w-px bg-gray-400 border-r border-white mx-1"></div>
      {utilityButtons.map(btn => <ToolbarButton key={btn.id} button={btn} />)}

    </div>
  );
};

export default Toolbar;