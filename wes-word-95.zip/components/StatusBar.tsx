import React from 'react';

interface StatusBarProps {
  fileName: string;
  wordCount: number;
  charCount: number;
}

const StatusBarPanel: React.FC<{ children: React.ReactNode, className?: string }> = ({ children, className }) => (
  <div className={`statusbar-panel px-2 py-0.5 border-t border-l border-gray-500 border-r border-b border-white min-w-[80px] text-center ${className || ''}`}>
    {children}
  </div>
);

const StatusBar: React.FC<StatusBarProps> = ({ fileName, wordCount, charCount }) => {
  return (
    <div className="statusbar bg-[#c0c0c0] text-black text-xs flex items-center border-t-2 border-white select-none">
      <StatusBarPanel className="flex-grow text-left">Ready</StatusBarPanel>
      <StatusBarPanel>Chars: {charCount}</StatusBarPanel>
      <StatusBarPanel>Words: {wordCount}</StatusBarPanel>
      {/* <StatusBarPanel>{fileName || "Untitled.txt"}</StatusBarPanel> */}
    </div>
  );
};

export default StatusBar;