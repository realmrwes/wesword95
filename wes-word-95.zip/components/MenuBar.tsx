import React, { useState, useRef, useEffect } from 'react';
import { MenuItem } from '../types';
import DropdownMenu from './DropdownMenu';
import { APP_TITLE } from '../constants';

interface MenuBarProps {
  onNew: () => void;
  onOpen: () => void;
  onSave: () => void; // This remains save as .txt
  onExportPDF: () => void;
  onExportDOCX: () => void;
  onSaveUsageStats: () => void;
  onCut: () => void;
  onCopy: () => void;
  onPaste: () => void;
  onAbout: () => void;
  fileName: string;
}

const MenuBarItem: React.FC<{
  label: string;
  menuItems: MenuItem[];
  isOpen: boolean;
  onClick: () => void;
  onClose: () => void;
}> = ({ label, menuItems, isOpen, onClick, onClose }) => {
  const menuRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(event.target as Node)) {
        onClose();
      }
    };
    if (isOpen) {
      document.addEventListener('mousedown', handleClickOutside);
    }
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [isOpen, onClose]);
  
  return (
    <div className="relative" ref={menuRef}>
      <button
        onClick={onClick}
        className={`px-2 py-0.5 text-sm ${isOpen ? 'bg-[#000080] text-white active-menu' : 'hover:bg-gray-300 active:bg-gray-400'}`}
        aria-haspopup="true"
        aria-expanded={isOpen}
      >
        {label}
      </button>
      {isOpen && <DropdownMenu items={menuItems} onClose={onClose} />}
    </div>
  );
};


const MenuBar: React.FC<MenuBarProps> = ({ 
  onNew, onOpen, onSave, onExportPDF, onExportDOCX, onSaveUsageStats,
  onCut, onCopy, onPaste, onAbout, fileName
}) => {
  const [openMenu, setOpenMenu] = useState<string | null>(null);

  const toggleMenu = (menuName: string) => {
    setOpenMenu(openMenu === menuName ? null : menuName);
  };

  const closeMenu = () => {
    setOpenMenu(null);
  };

  const fileMenuItems: MenuItem[] = [
    { label: 'New', action: onNew },
    { label: 'Open...', action: onOpen },
    { label: 'Save as TXT', action: onSave },
    { isSeparator: true },
    { label: 'Export as PDF...', action: onExportPDF },
    { label: 'Export as DOCX...', action: onExportDOCX },
    { isSeparator: true },
    { label: 'Save Usage Stats...', action: onSaveUsageStats },
    { isSeparator: true },
    { label: `About ${APP_TITLE}`, action: onAbout },
    { isSeparator: true },
    { label: 'Exit', action: () => { /* No-op in browser */ }, disabled: true },
  ];

  const editMenuItems: MenuItem[] = [
    { label: 'Undo', action: () => { document.execCommand('undo'); }, disabled: false },
    { label: 'Redo', action: () => { document.execCommand('redo'); }, disabled: false },
    { isSeparator: true },
    { label: 'Cut', action: onCut },
    { label: 'Copy', action: onCopy },
    { label: 'Paste', action: onPaste },
    { isSeparator: true },
    { label: 'Select All', action: () => { 
        const activeElement = document.activeElement;
        if (activeElement && 'select' in activeElement && typeof activeElement.select === 'function') {
            (activeElement as HTMLInputElement | HTMLTextAreaElement).select();
        }
      }, 
    },
  ];

  const displayFileName = fileName || "Untitled.txt";
  const titleBarText = `${APP_TITLE} - [${displayFileName}]`;

  return (
    <div className="bg-[#c0c0c0] text-black text-sm select-none">
      <div className="menubar-title-bar bg-[#000080] text-white px-2 py-0.5 text-xs font-bold">
        {titleBarText}
      </div>
      <div className="menubar-bar flex border-b-2 border-gray-400 shadow-sm px-1">
        <MenuBarItem label="File" menuItems={fileMenuItems} isOpen={openMenu === 'File'} onClick={() => toggleMenu('File')} onClose={closeMenu} />
        <MenuBarItem label="Edit" menuItems={editMenuItems} isOpen={openMenu === 'Edit'} onClick={() => toggleMenu('Edit')} onClose={closeMenu} />
      </div>
    </div>
  );
};

export default MenuBar;