import React from 'react';
import { MenuItem } from '../types';

interface DropdownMenuProps {
  items: MenuItem[];
  onClose: () => void;
}

const DropdownMenu: React.FC<DropdownMenuProps> = ({ items, onClose }) => {
  return (
    <div className="dropdown-menu absolute left-0 mt-1 w-56 bg-[#c0c0c0] border-t-2 border-l-2 border-white border-r-2 border-b-2 border-black shadow-md z-20 py-1">
      {items.map((item, index) =>
        item.isSeparator ? (
          <div key={`separator-${index}`} className="dropdown-menu-separator h-px bg-gray-500 border-b border-white my-1 mx-1"></div>
        ) : (
          <button
            key={`${item.label}-${index}`} // Ensure unique key
            onClick={() => {
              if (item.action && !item.disabled) {
                item.action();
              }
              onClose();
            }}
            disabled={item.disabled}
            className={`w-full text-left px-3 py-1 text-sm flex items-center
                        ${item.disabled ? 'text-gray-500' : 'text-black hover:bg-[#000080] hover:text-white active:bg-[#000050] active:text-white'}
                        focus:outline-none`}
          >
            <span className="flex-grow">{item.label}</span>
          </button>
        )
      )}
    </div>
  );
};

export default DropdownMenu;