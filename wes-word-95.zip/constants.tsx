import React from 'react';

export const APP_TITLE = "Wes Word 95";
export const DEFAULT_FILENAME = "Untitled.txt";

export const ICONS = {
  NEW_FILE: (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 16" fill="currentColor" className="w-4 h-4">
      <path d="M3 2.5A1.5 1.5 0 0 1 4.5 1h5A1.5 1.5 0 0 1 11 2.5V3h1.5A1.5 1.5 0 0 1 14 4.5v7a1.5 1.5 0 0 1-1.5 1.5h-9A1.5 1.5 0 0 1 2 11.5v-9A1.5 1.5 0 0 1 3.5 1H3V2.5ZM4.5 2A.5.5 0 0 0 4 2.5V3h6.5V2.5a.5.5 0 0 0-.5-.5h-5ZM13 4.5a.5.5 0 0 0-.5-.5H3.5a.5.5 0 0 0-.5.5v7a.5.5 0 0 0 .5.5h9a.5.5 0 0 0 .5-.5v-7Z" />
      <path d="M5 7h6v1H5V7Zm0 2h6v1H5V9Z" />
    </svg>
  ),
  OPEN_FILE: (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 16" fill="currentColor" className="w-4 h-4">
      <path d="M2 3.5A1.5 1.5 0 0 1 3.5 2h2.293a1.5 1.5 0 0 1 1.06.44L8.5 4H12.5A1.5 1.5 0 0 1 14 5.5V11.5A1.5 1.5 0 0 1 12.5 13H3.5A1.5 1.5 0 0 1 2 11.5V3.5ZM3.5 3a.5.5 0 0 0-.5.5v8a.5.5 0 0 0 .5.5h9a.5.5 0 0 0 .5-.5V5.5a.5.5 0 0 0-.5-.5H8.207a.5.5 0 0 1-.353-.146L6.207 3.707A.5.5 0 0 0 5.854 3H3.5Z" />
    </svg>
  ),
  SAVE_FILE: (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 16" fill="currentColor" className="w-4 h-4">
      <path d="M2 2.5A1.5 1.5 0 0 1 3.5 1h6.236a1.5 1.5 0 0 1 1.06.44l2.264 2.263A1.5 1.5 0 0 1 13.5 4.764V12.5a1.5 1.5 0 0 1-1.5 1.5h-9A1.5 1.5 0 0 1 2 12.5v-10ZM3.5 2A.5.5 0 0 0 3 2.5v10a.5.5 0 0 0 .5.5h9a.5.5 0 0 0 .5-.5V4.764a.5.5 0 0 0-.146-.353L10.114 2.147A.5.5 0 0 0 9.764 2H3.5Z" />
      <path d="M3 9.5A1.5 1.5 0 0 1 4.5 8h7A1.5 1.5 0 0 1 13 9.5v3A1.5 1.5 0 0 1 11.5 14h-7A1.5 1.5 0 0 1 3 12.5v-3ZM4.5 9a.5.5 0 0 0-.5.5v3a.5.5 0 0 0 .5.5h7a.5.5 0 0 0 .5-.5v-3a.5.5 0 0 0-.5-.5h-7Z" />
      <path d="M6 2.5A.5.5 0 0 1 6.5 2h3a.5.5 0 0 1 .5.5V5h-4V2.5Z" />
    </svg>
  ),
  CUT: (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 16" fill="currentColor" className="w-4 h-4">
      <path fillRule="evenodd" d="M4.28 3.22a.75.75 0 0 0-1.06 1.06l1.255 1.255a3.5 3.5 0 1 0 1.072 1.072L3.22 4.28Zm8.934.23a3.501 3.501 0 1 0-4.891 5.006l-.98.98A.75.75 0 0 0 8 10.25h-.25a.75.75 0 0 0-.75.75v.25a.75.75 0 0 0 .75.75h.25a.75.75 0 0 0 .75-.75v-.25a.75.75 0 0 0-.146-.44l.98-.98A3.501 3.501 0 0 0 13.214 3.45ZM11 6.5a2 2 0 1 1-4 0 2 2 0 0 1 4 0Zm-7.5 2a2 2 0 1 0 0-4 2 2 0 0 0 0 4Z" clipRule="evenodd" />
      <path d="M5.173 11.827a.75.75 0 1 0 1.06-1.06L4.5 9.033l-1.697 1.734a.75.75 0 1 0 1.061 1.06L5.173 11.827Z" />
      <path d="M11.827 5.173a.75.75 0 1 0-1.06 1.06L12.5 7.967l1.697-1.734a.75.75 0 1 0-1.061-1.06L11.827 5.173Z" />
    </svg>
  ),
  COPY: (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 16" fill="currentColor" className="w-4 h-4">
      <path d="M2.5 1A1.5 1.5 0 0 0 1 2.5v8.5A1.5 1.5 0 0 0 2.5 12.5H3V13a1 1 0 0 0 1 1h8.5a1.5 1.5 0 0 0 1.5-1.5v-8A1.5 1.5 0 0 0 12.5 3H12V2.5A1.5 1.5 0 0 0 10.5 1h-8Z" />
      <path d="M2 4.5A.5.5 0 0 1 2.5 4H4v8H2.5a.5.5 0 0 1-.5-.5v-7ZM10.5 2H4.61c.16.297.297.616.407.95.167.512.283 1.057.283 1.55H10V2.5a.5.5 0 0 0-.5-.5Z" />
    </svg>
  ),
  PASTE: (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 16" fill="currentColor" className="w-4 h-4">
      <path d="M3.5 2A1.5 1.5 0 0 0 2 3.5v9A1.5 1.5 0 0 0 3.5 14h9a1.5 1.5 0 0 0 1.5-1.5v-9A1.5 1.5 0 0 0 12.5 2h-9ZM11 4H5v1h6V4Zm0 2H5v1h6V6Z" />
      <path d="M5.5 1h5A.5.5 0 0 1 11 .5v.5H5V.5A.5.5 0 0 1 5.5 1Z" />
    </svg>
  ),
  INDENT_RIGHT: (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 16" fill="currentColor" className="w-4 h-4">
      <path d="M1.5 3.25a.75.75 0 0 1 .75-.75h11a.75.75 0 0 1 0 1.5h-11a.75.75 0 0 1-.75-.75Zm0 3a.75.75 0 0 1 .75-.75H8a.75.75 0 0 1 0 1.5H2.25a.75.75 0 0 1-.75-.75Zm0 3a.75.75 0 0 1 .75-.75h11a.75.75 0 0 1 0 1.5h-11a.75.75 0 0 1-.75-.75Zm0 3a.75.75 0 0 1 .75-.75H8a.75.75 0 0 1 0 1.5H2.25a.75.75 0 0 1-.75-.75Zm10.22-5.22a.75.75 0 0 1 1.06 0l2 2a.75.75 0 0 1 0 1.06l-2 2a.75.75 0 1 1-1.06-1.06L12.44 9l-.72-.72a.75.75 0 0 1 0-1.06Z"/>
    </svg>
  ),
  MOON: (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 16" fill="currentColor" className="w-4 h-4">
      <path d="M11.585 3.13a.75.75 0 0 0-1.054.205 5.403 5.403 0 0 1-.95 1.392A5.5 5.5 0 0 0 3.13 11.585a.75.75 0 0 0 .859 1.202A6.986 6.986 0 0 0 8 13.5a7 7 0 0 0 6.588-4.25.75.75 0 0 0-.64-1.063 5.403 5.403 0 0 1-1.073-.636A5.5 5.5 0 0 0 8.75 3.5a5.403 5.403 0 0 1 .628-2.316.75.75 0 0 0 .206-1.054Z"/>
    </svg>
  ),
  SUN: (
     <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 16" fill="currentColor" className="w-4 h-4">
      <path d="M8 10.5a2.5 2.5 0 1 0 0-5 2.5 2.5 0 0 0 0 5ZM8 12a4 4 0 1 1 0-8 4 4 0 0 1 0 8ZM11.25 3.75a.75.75 0 1 0-1.5 0 .75.75 0 0 0 1.5 0ZM14.5 7.25a.75.75 0 0 1 .75.75v.001a.75.75 0 0 1-1.5 0V7.25a.75.75 0 0 1 .75-.75ZM11.274 11.976a.75.75 0 1 0-1.06 1.06l-.001.001a.75.75 0 1 0 1.06-1.06l.001-.001ZM4.75 3.75a.75.75 0 1 0-1.5 0 .75.75 0 0 0 1.5 0ZM1.5 7.25a.75.75 0 0 1 .75.75v.001a.75.75 0 0 1-1.5 0V7.25A.75.75 0 0 1 1.5 7.25ZM4.726 11.976a.75.75 0 1 0-1.06 1.06l-.001.001a.75.75 0 1 0 1.06-1.06l.001-.001ZM7.25 1.5a.75.75 0 0 1 .75.75V2.25a.75.75 0 0 1-1.5 0V1.5a.75.75 0 0 1 .75-.75Zm0 11.5a.75.75 0 0 1 .75.75v.001a.75.75 0 0 1-1.5 0V13a.75.75 0 0 1 .75-.75Z"/>
    </svg>
  ),
  MEGAPHONE: (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 16" fill="currentColor" className="w-4 h-4">
      <path d="M10.75 1a.75.75 0 0 0-.75.75V3H3.5a.5.5 0 0 0-.5.5v8a.5.5 0 0 0 .5.5h6.5V14.25a.75.75 0 0 0 1.5 0V12h.25A1.75 1.75 0 0 0 13.5 10.25V4.75A1.75 1.75 0 0 0 11.75 3H10V1.75A.75.75 0 0 0 10.75 1ZM9.5 4.5V3.75a.75.75 0 0 1 .75-.75h.5a.75.75 0 0 1 .75.75v8.5a.75.75 0 0 1-.75.75h-.5a.75.75 0 0 1-.75-.75V11H3.5V4.5h6ZM11 4.75V10.25a.75.75 0 0 1-.75.75H10V4h.25a.75.75 0 0 1 .75.75Z" />
    </svg>
  ),
  ANGRY_MAN: ( // Nikola Jokic "Angrier" Face
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64" className="w-32 h-32">
      {/* Face background - slightly redder for anger */}
      <circle cx="32" cy="32" r="28" stroke="black" strokeWidth="1.5" fill="#F8BDBD" />
      
      {/* Hairline - Jokic style */}
      <path d="M16 22 Q 20 12, 32 12 Q 44 12, 48 22" stroke="black" strokeWidth="2.5" fill="#4A3728" />
      <path d="M16 22 Q 15 28, 18 32 L 18 22 Z" fill="#4A3728" stroke="black" strokeWidth="1.5" />
      <path d="M48 22 Q 49 28, 46 32 L 46 22 Z" fill="#4A3728" stroke="black" strokeWidth="1.5" />

      {/* Ears */}
      <path d="M10 30 Q 8 32, 10 34 C 13 36, 13 28, 10 30" fill="#F8BDBD" stroke="black" strokeWidth="1.5" />
      <path d="M54 30 Q 56 32, 54 34 C 51 36, 51 28, 54 30" fill="#F8BDBD" stroke="black" strokeWidth="1.5" />
      
      {/* Eyes (Angry/Focused) */}
      <ellipse cx="23" cy="29" rx="4.5" ry="2.5" fill="white" stroke="black" strokeWidth="1"/>
      <circle cx="23" cy="29" r="1.2" fill="black" />
      <ellipse cx="41" cy="29" rx="4.5" ry="2.5" fill="white" stroke="black" strokeWidth="1"/>
      <circle cx="41" cy="29" r="1.2" fill="black" />
      
      {/* Eyebrows (Very Angry) */}
      <path d="M16 26 L 24 20 L 30 25" stroke="black" strokeWidth="4" fill="none" strokeLinecap="round" />
      <path d="M48 26 L 40 20 L 34 25" stroke="black" strokeWidth="4" fill="none" strokeLinecap="round" />
      
      {/* Nose (Simple Jokic-esque) */}
      <path d="M30 32 C 30 38, 34 38, 34 32 Q 32 34, 30 32" fill="#E0A0A0" stroke="black" strokeWidth="1"/>
      
      {/* Mouth (Aggressive Frown/Snarl) */}
      <path d="M20 50 Q 32 38, 44 50 C 38 56, 26 56, 20 50" stroke="black" strokeWidth="3" fill="#8B0000" />

      {/* Light Beard Stubble */}
      <g stroke="black" strokeWidth="0.5" opacity="0.6">
        <path d="M20 40 Q 32 50, 44 40" fill="none" strokeLinecap="round" strokeDasharray="1 2"/>
        <path d="M20 40 C 18 45, 22 52, 32 54 C 42 52, 46 45, 44 40" fill="none" strokeLinecap="round" strokeDasharray="0.5 1.5"/>
        <line x1="19" y1="37" x2="20" y2="38" /> <line x1="21" y1="39" x2="22" y2="40" />
        <line x1="20" y1="42" x2="21" y2="43" /> <line x1="23" y1="44" x2="24" y2="45" />
        <line x1="45" y1="37" x2="44" y2="38" /> <line x1="43" y1="39" x2="42" y2="40" />
        <line x1="44" y1="42" x2="43" y2="43" /> <line x1="41" y1="44" x2="40" y2="45" />
        <line x1="28" y1="49" x2="29" y2="49.5" /> <line x1="30.5" y1="50" x2="31.5" y2="50" /> <line x1="33" y1="49.5" x2="34" y2="49" />
        <line x1="26" y1="46" x2="26.5" y2="46.5" /> <line x1="37" y1="46.5" x2="37.5" y2="46" />
      </g>
    </svg>
  ),
};

export const AVAILABLE_FONTS = [
  { name: 'Times New Roman', family: '"Times New Roman", Times, serif' },
];

// Sound for encouragement mode
const sampleRate = 8000;
const duration = 0.25; // seconds
const frequency = 220; // Hz (A3 - lower pitch for a "horn" like sound)
const numSamples = Math.floor(sampleRate * duration);
const amplitude = 127; // For 8-bit audio
let audioData = "";
for (let i = 0; i < numSamples; i++) {
  const sampleValue = Math.floor(amplitude * Math.sin(2 * Math.PI * frequency * (i / sampleRate)));
  audioData += String.fromCharCode(128 + sampleValue); // 8-bit unsigned PCM
}
const header = "RIFF" +
  String.fromCharCode.apply(null, new Uint32Array([36 + numSamples]).buffer) + 
  "WAVEfmt " +
  String.fromCharCode(16,0,0,0) + 
  String.fromCharCode(1,0) + 
  String.fromCharCode(1,0) + 
  String.fromCharCode.apply(null, new Uint32Array([sampleRate]).buffer) + 
  String.fromCharCode.apply(null, new Uint32Array([sampleRate]).buffer) + 
  String.fromCharCode(1,0) + 
  String.fromCharCode(8,0) + 
  "data" +
  String.fromCharCode.apply(null, new Uint32Array([numSamples]).buffer); 
export const FOG_HORN_SOUND_URI = "data:audio/wav;base64," + btoa(header + audioData);